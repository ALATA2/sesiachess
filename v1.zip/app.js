/**
 * BATTLE CHESS 3D - Codice di Gioco Principale
 * Sviluppato in Three.js con logica scacchi via Chess.js ed animazioni via GSAP.
 */

// ==========================================================================
// 1. CONFIGURAZIONE ASSETS (.GLB) E ANIMAZIONI
// ==========================================================================

/**
 * dizionario CHESS_ASSETS:
 * Inserisci qui i percorsi dei tuoi file .glb quando saranno pronti.
 * Esempio: p: "assets/models/white_pawn.glb"
 * Se lasciati vuoti "", il sistema genererà automaticamente delle geometrie
 * procedurali 3D (cilindri/coni) differenziate in altezza e colore per i test.
 */
const CHESS_ASSETS = {
    white: {
        p: "", // Pedone (Pawn)
        r: "", // Torre (Rook)
        n: "", // Cavallo (Knight)
        b: "", // Alfiere (Bishop)
        q: "", // Regina (Queen)
        k: ""  // Re (King)
    },
    black: {
        p: "", // Pedone
        r: "", // Torre
        n: "", // Cavallo
        b: "", // Alfiere
        q: "", // Regina
        k: ""  // Re
    }
};

// Nome delle animazioni attese nei tuoi file .glb
const ANIMATION_NAMES = {
    idle: 'idle',
    walk: 'walk',
    attack: 'attack',
    die: 'die'
};

// Categoria di cache per i modelli GLB già caricati, per evitare di ricaricarli
const gltfCache = {
    white: {},
    black: {}
};

// ==========================================================================
// 2. STATO DEL GIOCO E VARIABILI GLOBALI
// ==========================================================================
let scene, camera, renderer, controls;
let chess; // Istanza di Chess.js per la logica
let boardSquares3D = {}; // Mappa: 'e4' -> Mesh della tessera
let pieceMeshes = {};    // Mappa: 'e4' -> Oggetto Pezzo { mesh, type, color, mixer, animations }
let mixers = [];         // Mixer attivi per le animazioni GLTF
let clock;

// Parametri di interazione
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const pointerStart = new THREE.Vector2();
let selectedSquare = null;
let validMoves = [];
let isAnimating = false; // Blocca input durante le animazioni di attacco/spostamento
let isTopDownView = false;

// Dimensioni della scacchiera
const TILE_SIZE = 2;
const BOARD_OFFSET = 3.5; // (8 - 1) / 2 per centrare l'asse (0,0)

// Colori dei materiali PBR
const COLOR_WHITE_TILE = 0xe8dec9; // Crema
const COLOR_BLACK_TILE = 0x2c2c35; // Antracite/Nero opaco
const COLOR_WHITE_PIECE = 0xfcf8f0; // Ceramica bianca lucida
const COLOR_BLACK_PIECE = 0x2a2d32; // Metallo satinato scuro
const COLOR_GOLD_HIGHLIGHT = 0xe6c875; // Selezionato (Oro)
const COLOR_BLUE_HIGHLIGHT = 0x5a9eff; // Mossa Valida (Blu)
const COLOR_RED_HIGHLIGHT = 0xff5a5a;  // Cattura Mossa Valida (Rosso)

// ==========================================================================
// 3. INIZIALIZZAZIONE SCENA E AVVIO
// ==========================================================================
window.addEventListener('DOMContentLoaded', () => {
    initEngine();
    initChessLogic();
    buildBoard();
    setupLights();
    loadAllPieces().then(() => {
        // Nascondi overlay di caricamento
        document.getElementById('loading-overlay').classList.add('hidden');
        animate();
    });
    setupUIEvents();
});

/**
 * Configura il motore grafico Three.js (Renderer, Camera, ShadowMap, ToneMapping)
 */
function initEngine() {
    const container = document.getElementById('canvas-container');
    clock = new THREE.Clock();

    // Scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0b0f);
    scene.fog = new THREE.FogExp2(0x0b0b0f, 0.025);

    // Renderer ad alta qualità
    renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    
    // Supporto ombre fotorealistiche
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Colori e Tone Mapping
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;
    renderer.outputEncoding = THREE.sRGBEncoding;

    container.appendChild(renderer.domElement);

    // Camera iniziale 3D Isometrica
    camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 100);
    resetCameraPosition(false); // Imposta posizione iniziale senza transizione

    // Orbit Controls
    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 - 0.05; // Impedisci di andare sotto la scacchiera
    controls.minDistance = 8;
    controls.maxDistance = 35;

    // Gestione ridimensionamento finestra
    window.addEventListener('resize', onWindowResize);
}

/**
 * Inizializza il motore logico chess.js
 */
function initChessLogic() {
    chess = new Chess();
}

/**
 * Imposta le luci della scena (PBR richiede luci accurate)
 */
function setupLights() {
    // Luce Ambientale soffusa
    const ambientLight = new THREE.AmbientLight(0xdff0ff, 0.4);
    scene.add(ambientLight);

    // Luce Direzionale principale (Sole) per ombre nitide
    const dirLight = new THREE.DirectionalLight(0xfff8e7, 1.2);
    dirLight.position.set(8, 18, 10);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 40;
    
    // Dimensione del frustum dell'ombra per coprire l'intera scacchiera
    const d = 12;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0005;

    scene.add(dirLight);

    // Luce di riempimento azzurra dal lato opposto
    const fillLight = new THREE.DirectionalLight(0x7fbfff, 0.4);
    fillLight.position.set(-8, 10, -10);
    scene.add(fillLight);

    // Piccolo punto luce caldo al centro per atmosfera
    const pointLight = new THREE.PointLight(0xe6c875, 0.5, 30);
    pointLight.position.set(0, 5, 0);
    scene.add(pointLight);
}

// ==========================================================================
// 4. COSTRUZIONE SCACCHIERA 3D
// ==========================================================================

/**
 * Costruisce la scacchiera 3D fisica sul piano XZ
 */
function buildBoard() {
    const tileGeo = new THREE.BoxGeometry(TILE_SIZE, 0.2, TILE_SIZE);
    
    // Creazione delle tessere 8x8
    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const isLight = (r + c) % 2 === 1; // chess.js a1 è scura, a8 è chiara
            const squareName = coordsToAlgebraic(r, c);

            // Materiali PBR con proprietà fisiche realistiche (lucidezza/rugosità)
            const tileMat = new THREE.MeshStandardMaterial({
                color: isLight ? COLOR_WHITE_TILE : COLOR_BLACK_TILE,
                roughness: isLight ? 0.25 : 0.4,
                metalness: 0.1,
                clearcoat: 0.1,
                clearcoatRoughness: 0.1
            });

            const tile = new THREE.Mesh(tileGeo, tileMat);
            
            // Posizionamento centrato rispetto all'origine
            const x = (c - BOARD_OFFSET) * TILE_SIZE;
            const z = (BOARD_OFFSET - r) * TILE_SIZE;
            tile.position.set(x, 0, z);
            tile.receiveShadow = true;
            
            // Salviamo metadati per Raycasting
            tile.userData = { square: squareName, isTile: true };
            
            scene.add(tile);
            boardSquares3D[squareName] = tile;
        }
    }

    // Aggiungi una cornice di legno scuro intorno alla scacchiera
    const frameGeo = new THREE.BoxGeometry(TILE_SIZE * 8 + 0.8, 0.3, TILE_SIZE * 8 + 0.8);
    const frameMat = new THREE.MeshStandardMaterial({
        color: 0x1a0f0a,
        roughness: 0.6,
        metalness: 0.1
    });
    const frame = new THREE.Mesh(frameGeo, frameMat);
    frame.position.set(0, -0.11, 0);
    frame.receiveShadow = true;
    scene.add(frame);

    // Lettere e Numeri di bordo
    createBoardLabels();
}

/**
 * Crea le etichette delle coordinate (A-H, 1-8) sui bordi
 */
function createBoardLabels() {
    const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    const labelParent = new THREE.Group();

    // Nota: Usiamo canvas 2D dinamici come texture per creare scritte 3D
    function makeLabelTexture(text) {
        const canvas = document.createElement('canvas');
        canvas.width = 64;
        canvas.height = 64;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#101018';
        ctx.fillRect(0,0,64,64);
        ctx.fillStyle = '#e6c875';
        ctx.font = 'bold 36px Cinzel, serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, 32, 32);
        
        const texture = new THREE.CanvasTexture(canvas);
        return new THREE.MeshStandardMaterial({ map: texture, roughness: 0.4 });
    }

    const labelGeo = new THREE.PlaneGeometry(0.6, 0.6);

    for(let i=0; i<8; i++) {
        // Lettere su lato Z positivo
        const matL = makeLabelTexture(letters[i]);
        const labelL = new THREE.Mesh(labelGeo, matL);
        labelL.position.set((i - BOARD_OFFSET) * TILE_SIZE, 0.16, (BOARD_OFFSET + 0.6) * TILE_SIZE);
        labelL.rotation.x = -Math.PI / 2;
        labelParent.add(labelL);

        // Numeri su lato X negativo
        const matN = makeLabelTexture((i + 1).toString());
        const labelN = new THREE.Mesh(labelGeo, matN);
        labelN.position.set(-(BOARD_OFFSET + 0.6) * TILE_SIZE, 0.16, (BOARD_OFFSET - i) * TILE_SIZE);
        labelN.rotation.x = -Math.PI / 2;
        labelN.rotation.z = Math.PI / 2;
        labelParent.add(labelN);
    }
    scene.add(labelParent);
}

// ==========================================================================
// 5. CARICAMENTO MODELLI O GENERAZIONE FALLBACK (PLACEHOLDER)
// ==========================================================================

/**
 * Carica o crea proceduralmente tutti i pezzi correnti della scacchiera
 */
function loadAllPieces() {
    const boardState = chess.board();
    const loadPromises = [];

    // Ripulisci pezzi attuali
    for (let sq in pieceMeshes) {
        scene.remove(pieceMeshes[sq].mesh);
    }
    pieceMeshes = {};
    mixers = [];

    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const piece = boardState[r][c];
            if (piece) {
                const squareName = coordsToAlgebraic(r, c);
                const color = piece.color; // 'w' o 'b'
                const type = piece.type;   // 'p', 'r', 'n', 'b', 'q', 'k'
                
                const promise = spawnPiece(type, color, squareName);
                loadPromises.push(promise);
            }
        }
    }

    return Promise.all(loadPromises);
}

/**
 * Istanzia un singolo pezzo (GLB se presente, altrimenti Geometria Fallback)
 */
function spawnPiece(type, color, square) {
    return new Promise((resolve) => {
        const assetColor = color === 'w' ? 'white' : 'black';
        const modelPath = CHESS_ASSETS[assetColor][type];

        if (modelPath && modelPath !== "") {
            // ==========================================
            // [GLB LOADER] - ZONA CARICAMENTO FILE ESTERNI
            // Se specifichi i percorsi nel dizionario CHESS_ASSETS in alto,
            // questa sezione caricherà i tuoi modelli 3D.
            // ==========================================
            const loader = new THREE.GLTFLoader();
            loader.load(modelPath, 
                (gltf) => {
                    const cloned = cloneGltf(gltf);
                    const mesh = cloned.scene;
                    
                    // Configura ombre per tutti i nodi del modello
                    mesh.traverse(child => {
                        if (child.isMesh) {
                            child.castShadow = true;
                            child.receiveShadow = true;
                        }
                    });

                    // Crea Mixer per le animazioni scheletriche
                    let mixer = null;
                    let animationsMap = {};
                    if (cloned.animations && cloned.animations.length > 0) {
                        mixer = new THREE.AnimationMixer(mesh);
                        mixers.push(mixer);
                        cloned.animations.forEach(clip => {
                            animationsMap[clip.name] = clip;
                        });
                    }

                    setupPieceTransform(mesh, square, color);
                    
                    pieceMeshes[square] = {
                        mesh: mesh,
                        type: type,
                        color: color,
                        mixer: mixer,
                        animations: animationsMap,
                        activeAction: null,
                        isFallback: false
                    };
                    
                    scene.add(mesh);
                    playPieceAnimation(pieceMeshes[square], ANIMATION_NAMES.idle);
                    resolve();
                },
                (xhr) => {
                    // Aggiorna la barra di caricamento
                    if (xhr.total > 0) {
                        const pct = (xhr.loaded / xhr.total) * 100;
                        document.getElementById('progress-bar').style.width = pct + '%';
                        document.getElementById('loading-status').innerText = `Caricamento: ${Math.round(pct)}%`;
                    }
                },
                (error) => {
                    console.warn(`Errore caricamento GLB per ${type} (${color}). Uso fallback.`, error);
                    fallbackPieceInstantiation(type, color, square);
                    resolve();
                }
            );
        } else {
            // Nessun GLB specificato -> Usa la geometria procedurale di fallback
            fallbackPieceInstantiation(type, color, square);
            resolve();
        }
    });
}

/**
 * Instanziazione del pezzo di fallback procedurale
 */
function fallbackPieceInstantiation(type, color, square) {
    const mesh = createFallbackGeometry(type, color);
    setupPieceTransform(mesh, square, color);
    
    pieceMeshes[square] = {
        mesh: mesh,
        type: type,
        color: color,
        mixer: null,
        animations: {},
        activeAction: null,
        isFallback: true
    };
    
    scene.add(mesh);
}

/**
 * Configura posizione e rotazione iniziale del pezzo sulla scacchiera
 */
function setupPieceTransform(mesh, square, color) {
    const coords = algebraicToCoords(square);
    mesh.position.set(coords.x, 0.1, coords.z);
    
    // Rotazione iniziale dei pezzi per farli guardare l'avversario
    // Il Bianco (w) guarda verso la Z negativa (rotazione 180° = Math.PI)
    // Il Nero (b) guarda verso la Z positiva (rotazione 0°)
    mesh.rotation.y = color === 'w' ? Math.PI : 0;
    
    mesh.userData = { square: square, isPiece: true };
}

/**
 * Crea geometrie 3D PBR distinte per ogni tipo di pezzo
 */
function createFallbackGeometry(type, color) {
    const group = new THREE.Group();
    const colHex = color === 'w' ? COLOR_WHITE_PIECE : COLOR_BLACK_PIECE;
    const rough = color === 'w' ? 0.15 : 0.3;
    const metal = color === 'w' ? 0.1 : 0.25;

    const material = new THREE.MeshStandardMaterial({
        color: colHex,
        roughness: rough,
        metalness: metal,
        clearcoat: 0.2,
        clearcoatRoughness: 0.1
    });

    let bodyGeo;
    let height = 1.0;

    // Crea un basamento comune per tutti i pezzi (stile scacchi classici)
    const baseGeo = new THREE.CylinderGeometry(0.6, 0.7, 0.2, 16);
    const baseMesh = new THREE.Mesh(baseGeo, material);
    baseMesh.position.y = 0.1;
    baseMesh.castShadow = true;
    baseMesh.receiveShadow = true;
    group.add(baseMesh);

    // Differenziazione forme/altezze dei pezzi
    switch (type) {
        case 'p': // Pedone: Sfera su cilindro corto
            height = 1.1;
            bodyGeo = new THREE.CylinderGeometry(0.3, 0.5, 0.7, 16);
            const bodyP = new THREE.Mesh(bodyGeo, material);
            bodyP.position.y = 0.55;
            const headGeo = new THREE.SphereGeometry(0.35, 16, 16);
            const headP = new THREE.Mesh(headGeo, material);
            headP.position.y = 1.0;
            group.add(bodyP, headP);
            break;

        case 'r': // Torre: Cilindro dritto merlato
            height = 1.4;
            bodyGeo = new THREE.CylinderGeometry(0.45, 0.55, 1.0, 16);
            const bodyR = new THREE.Mesh(bodyGeo, material);
            bodyR.position.y = 0.7;
            const topR = new THREE.CylinderGeometry(0.55, 0.45, 0.25, 16);
            const topMeshR = new THREE.Mesh(topR, material);
            topMeshR.position.y = 1.3;
            group.add(bodyR, topMeshR);
            break;

        case 'n': // Cavallo: Corpo con muso sporgente (Box ruotati)
            height = 1.5;
            bodyGeo = new THREE.CylinderGeometry(0.4, 0.5, 0.9, 16);
            const bodyN = new THREE.Mesh(bodyGeo, material);
            bodyN.position.y = 0.65;
            
            const headNGeo = new THREE.BoxGeometry(0.4, 0.5, 0.75);
            const headN = new THREE.Mesh(headNGeo, material);
            headN.position.set(0, 1.2, 0.15);
            headN.rotation.x = -0.2; // Muso inclinato in avanti
            
            const earsNGeo = new THREE.ConeGeometry(0.1, 0.3, 4);
            const earL = new THREE.Mesh(earsNGeo, material);
            earL.position.set(-0.15, 1.5, -0.1);
            const earR = new THREE.Mesh(earsNGeo, material);
            earR.position.set(0.15, 1.5, -0.1);
            
            group.add(bodyN, headN, earL, earR);
            break;

        case 'b': // Alfiere: Cilindro slanciato con testa a goccia
            height = 1.7;
            bodyGeo = new THREE.CylinderGeometry(0.3, 0.5, 1.1, 16);
            const bodyB = new THREE.Mesh(bodyGeo, material);
            bodyB.position.y = 0.75;
            
            const headBGeo = new THREE.ConeGeometry(0.35, 0.7, 16);
            const headB = new THREE.Mesh(headBGeo, material);
            headB.position.y = 1.45;
            
            const tipBGeo = new THREE.SphereGeometry(0.1, 8, 8);
            const tipB = new THREE.Mesh(tipBGeo, material);
            tipB.position.y = 1.85;
            
            group.add(bodyB, headB, tipB);
            break;

        case 'q': // Regina: Tronco di cono con corona (Toro sormontato da sfere)
            height = 2.1;
            bodyGeo = new THREE.CylinderGeometry(0.35, 0.6, 1.4, 16);
            const bodyQ = new THREE.Mesh(bodyGeo, material);
            bodyQ.position.y = 0.9;
            
            const crownQGeo = new THREE.TorusGeometry(0.38, 0.15, 8, 24);
            const crownQ = new THREE.Mesh(crownQGeo, material);
            crownQ.position.y = 1.7;
            crownQ.rotation.x = Math.PI / 2;
            
            const tipQGeo = new THREE.SphereGeometry(0.15, 8, 8);
            const tipQ = new THREE.Mesh(tipQGeo, material);
            tipQ.position.y = 2.0;
            
            group.add(bodyQ, crownQ, tipQ);
            break;

        case 'k': // Re: Tronco di cono con croce in cima
            height = 2.3;
            bodyGeo = new THREE.CylinderGeometry(0.38, 0.6, 1.5, 16);
            const bodyK = new THREE.Mesh(bodyGeo, material);
            bodyK.position.y = 0.95;
            
            const crownKGeo = new THREE.CylinderGeometry(0.5, 0.4, 0.3, 16);
            const crownK = new THREE.Mesh(crownKGeo, material);
            crownK.position.y = 1.85;
            
            // Croce
            const crossGroup = new THREE.Group();
            const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.4, 0.12), material);
            const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.12, 0.12), material);
            crossV.position.y = 2.15;
            crossH.position.y = 2.22;
            crossGroup.add(crossV, crossH);
            
            group.add(bodyK, crownK, crossGroup);
            break;
    }

    // Configura le ombre per tutte le parti del pezzo procedurale
    group.traverse(child => {
        if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
        }
    });

    return group;
}

/**
 * Clona un modello GLTF preservando lo scheletro e le animazioni (Skeletal Rigging Support)
 */
function cloneGltf(gltf) {
    const clone = {
        scene: gltf.scene.clone(),
        animations: gltf.animations
    };
    
    // Supporto rigging per mesh scheletriche clonate
    const skinnedMeshes = {};
    gltf.scene.traverse(node => {
        if (node.isSkinnedMesh) {
            skinnedMeshes[node.name] = node;
        }
    });
    
    clone.scene.traverse(node => {
        if (node.isSkinnedMesh) {
            const originalMesh = skinnedMeshes[node.name];
            if (originalMesh) {
                node.geometry = originalMesh.geometry;
                node.material = originalMesh.material;
                node.skeleton = originalMesh.skeleton.clone();
                
                const cloneBones = {};
                clone.scene.traverse(cloneNode => {
                    if (cloneNode.isBone) cloneBones[cloneNode.name] = cloneNode;
                });
                
                const bones = [];
                for (let i = 0; i < originalMesh.skeleton.bones.length; i++) {
                    const boneName = originalMesh.skeleton.bones[i].name;
                    bones.push(cloneBones[boneName] || originalMesh.skeleton.bones[i]);
                }
                node.bind(new THREE.Skeleton(bones, originalMesh.skeleton.boneInverses), node.matrixWorld);
            }
        }
    });
    
    return clone;
}

// ==========================================================================
// 6. GESTORE DELLE ANIMAZIONI (MODÈLLI E COMPORTAMENTI FALLBACK)
// ==========================================================================

/**
 * ==========================================================================
 * [ANIMATION SYSTEM] - FUNZIONE PREVISTA PER I TUOI .GLB ANIMATI
 * Esegue la transizione tra le clip di animazione (idle, walk, attack, die).
 * Gestisce anche i movimenti simulati via GSAP se stai usando i pezzi di fallback.
 * ==========================================================================
 */
function playPieceAnimation(piece, animationName, loop = true) {
    if (!piece) return;

    // A) Se il pezzo ha un AnimationMixer (Caricato da GLB reale)
    if (piece.mixer && piece.animations[animationName]) {
        const clip = piece.animations[animationName];
        const action = piece.mixer.clipAction(clip);
        
        // Configura il loop
        if (!loop) {
            action.loop = THREE.LoopOnce;
            action.clampWhenFinished = true;
        } else {
            action.loop = THREE.LoopRepeat;
        }

        // Dissolvenza morbida tra le animazioni (CrossFade)
        if (piece.activeAction && piece.activeAction !== action) {
            piece.activeAction.fadeOut(0.2);
            action.reset().fadeIn(0.2).play();
        } else {
            action.play();
        }
        piece.activeAction = action;
    } 
    // B) Animazione di fallback per pezzi geometrici procedurali
    else if (piece.isFallback) {
        // Le animazioni procedurali simulate via GSAP sono gestite 
        // localmente durante le routine di movimento e combattimento.
    }
}

// ==========================================================================
// 7. SISTEMA DI MOVIMENTO E COMBATTIMENTO (LOGICA BATTLE CHESS)
// ==========================================================================

/**
 * Esegue il movimento tridimensionale di un pezzo, decidendo se è mossa
 * pacifica (scivolamento) o attacco/combattimento (avvicinamento, colpo, morte).
 */
function executeMove3D(fromSq, toSq, moveLogInfo) {
    isAnimating = true;
    
    const movingPiece = pieceMeshes[fromSq];
    const targetPiece = pieceMeshes[toSq]; // Presente solo in caso di cattura

    const coordsA = algebraicToCoords(fromSq);
    const coordsB = algebraicToCoords(toSq);

    // Rimuovi la chiave dal dizionario dei pezzi immediatamente per liberare lo square
    delete pieceMeshes[fromSq];

    if (targetPiece) {
        // CATTURA CON COMBATTIMENTO
        
        // 1. Sposta l'attaccante in modalità "Camminata" fino a una distanza ravvicinata dall'avversario
        const angle = Math.atan2(coordsB.z - coordsA.z, coordsB.x - coordsA.x);
        
        // Punto di arresto pre-combattimento (leggermente prima del centro della casella)
        const stopDistance = 0.8; 
        const combatPosX = coordsB.x - Math.cos(angle) * stopDistance;
        const combatPosZ = coordsB.z - Math.sin(angle) * stopDistance;

        // Ruota l'attaccante verso la vittima
        movingPiece.mesh.lookAt(new THREE.Vector3(coordsB.x, movingPiece.mesh.position.y, coordsB.z));
        targetPiece.mesh.lookAt(new THREE.Vector3(coordsA.x, targetPiece.mesh.position.y, coordsA.z));

        // Fase 1: Cammina verso la posizione di combattimento
        playPieceAnimation(movingPiece, ANIMATION_NAMES.walk);
        
        const walkDuration = 1.2;
        const tl = gsap.timeline({
            onComplete: () => {
                // Fase 2: Combattimento (Attacco dell'attaccante e Morte del difensore)
                playPieceAnimation(movingPiece, ANIMATION_NAMES.attack, false);
                
                // Ritardo per sincronizzare il colpo
                gsap.delayedCall(0.5, () => {
                    playPieceAnimation(targetPiece, ANIMATION_NAMES.die, false);
                    
                    if (targetPiece.isFallback) {
                        // Animazione di morte procedurale (rotazione e caduta sotto il piano)
                        gsap.to(targetPiece.mesh.rotation, { x: Math.PI / 2, z: Math.PI / 4, duration: 0.6 });
                        gsap.to(targetPiece.mesh.position, { y: -3, duration: 0.8, ease: "power2.in" });
                        gsap.to(targetPiece.mesh.scale, { x: 0.01, y: 0.01, z: 0.01, duration: 0.8, onComplete: cleanupTarget });
                    } else {
                        // Attendi la fine dell'animazione GLTF del difensore
                        gsap.delayedCall(1.2, cleanupTarget);
                    }
                });
            }
        });

        // Spostamento fisico verso la casella di combattimento
        tl.to(movingPiece.mesh.position, { x: combatPosX, z: combatPosZ, duration: walkDuration, ease: "power1.inOut" });
        
        // Se è fallback, simula il rimbalzo dei passi (effetto saltello)
        if (movingPiece.isFallback) {
            tl.to(movingPiece.mesh.position, { y: 0.8, duration: walkDuration / 4, yoyo: true, repeat: 3, ease: "power1.out" }, 0);
        }

        function cleanupTarget() {
            // Rimuovi fisicamente il pezzo catturato dalla scena
            scene.remove(targetPiece.mesh);
            if (targetPiece.mixer) {
                const idx = mixers.indexOf(targetPiece.mixer);
                if (idx > -1) mixers.splice(idx, 1);
            }
            
            // Fase 3: L'attaccante prende definitivamente possesso della casella target
            playPieceAnimation(movingPiece, ANIMATION_NAMES.walk);
            
            const stepFinal = gsap.timeline({
                onComplete: () => {
                    // Ripristina l'orientamento di default (in base al colore del giocatore)
                    gsap.to(movingPiece.mesh.rotation, {
                        y: movingPiece.color === 'w' ? Math.PI : 0,
                        duration: 0.3,
                        onComplete: () => {
                            playPieceAnimation(movingPiece, ANIMATION_NAMES.idle);
                            finalizeState();
                        }
                    });
                }
            });

            stepFinal.to(movingPiece.mesh.position, { x: coordsB.x, z: coordsB.z, duration: 0.4, ease: "power1.out" });
            if (movingPiece.isFallback) {
                stepFinal.to(movingPiece.mesh.position, { y: 0.1, duration: 0.4, ease: "bounce.out" }, 0);
            }
        }

    } else {
        // MOVIMENTO PACIFICO (SLIDE)
        playPieceAnimation(movingPiece, ANIMATION_NAMES.walk);
        
        const moveDuration = 0.8;
        const tl = gsap.timeline({
            onComplete: () => {
                playPieceAnimation(movingPiece, ANIMATION_NAMES.idle);
                finalizeState();
            }
        });

        // Spostamento XZ
        tl.to(movingPiece.mesh.position, { x: coordsB.x, z: coordsB.z, duration: moveDuration, ease: "power2.inOut" }, 0);
        
        // Effetto salto parabolico sull'asse Y
        tl.to(movingPiece.mesh.position, { y: 1.0, duration: moveDuration / 2, yoyo: true, repeat: 1, ease: "power1.out" }, 0);
    }

    function finalizeState() {
        // Registra la nuova posizione della mesh
        movingPiece.mesh.userData.square = toSq;
        pieceMeshes[toSq] = movingPiece;
        
        // Sincronizza lo stato logico in chess.js ed esegui la mossa
        chess.move({ from: fromSq, to: toSq, promotion: 'q' }); // Auto-promozione a Regina per semplicità

        // Controlla En Passant o Arrocco ed effettua aggiornamenti di scena
        syncSpecialMoves(fromSq, toSq);

        updateUI(moveLogInfo);
        
        // Verifica fine partita
        checkGameStatus();
        
        isAnimating = false;
    }
}

/**
 * Gestisce mosse speciali come Arrocco (sposta la torre) ed En Passant (rimuove il pedone catturato)
 */
function syncSpecialMoves(fromSq, toSq) {
    // 1. Rileva Arrocco (il Re si sposta di 2 caselle orizzontalmente)
    const piece = pieceMeshes[toSq];
    if (piece.type === 'k') {
        const fromCol = fromSq.charCodeAt(0);
        const toCol = toSq.charCodeAt(0);
        if (Math.abs(fromCol - toCol) > 1) {
            // È un arrocco. Identifichiamo torre e posizioni
            let rookFrom, rookTo;
            const rank = piece.color === 'w' ? '1' : '8';
            if (toCol === 103) { // Lato Re ('g')
                rookFrom = 'h' + rank;
                rookTo = 'f' + rank;
            } else if (toCol === 99) { // Lato Regina ('c')
                rookFrom = 'a' + rank;
                rookTo = 'd' + rank;
            }

            if (rookFrom && pieceMeshes[rookFrom]) {
                const rook = pieceMeshes[rookFrom];
                delete pieceMeshes[rookFrom];
                
                const rookCoords = algebraicToCoords(rookTo);
                // Spostamento istantaneo della torre per l'arrocco (o mini-slide)
                gsap.to(rook.mesh.position, {
                    x: rookCoords.x,
                    z: rookCoords.z,
                    duration: 0.4,
                    ease: "power1.inOut",
                    onComplete: () => {
                        rook.mesh.userData.square = rookTo;
                        pieceMeshes[rookTo] = rook;
                    }
                });
            }
        }
    }

    // 2. Rileva En Passant (il pedone si sposta in diagonale su una casella vuota)
    // Se un pedone finisce su una casella diversa da quella di partenza del suo X, ma non c'era pezzo
    // Nota: chess.js rileva ed elimina il pezzo internamente. Sincronizziamo la grafica.
    const boardState = chess.board();
    // Cerchiamo le discrepanze tra la scacchiera logica chess.js e le nostre mesh 3D
    for (let sq in pieceMeshes) {
        const col = sq.charCodeAt(0) - 97;
        const row = 8 - parseInt(sq.charAt(1));
        const boardPiece = boardState[row][col];
        
        // Se c'è una mesh 3D in 'sq' ma nella logica la casella è vuota, rimuovila (catturata)
        if (!boardPiece) {
            scene.remove(pieceMeshes[sq].mesh);
            if (pieceMeshes[sq].mixer) {
                const idx = mixers.indexOf(pieceMeshes[sq].mixer);
                if (idx > -1) mixers.splice(idx, 1);
            }
            delete pieceMeshes[sq];
        } else if (boardPiece.type !== pieceMeshes[sq].type) {
            // Se il tipo di pezzo è cambiato (es. promozione da pedone a regina)
            scene.remove(pieceMeshes[sq].mesh);
            if (pieceMeshes[sq].mixer) {
                const idx = mixers.indexOf(pieceMeshes[sq].mixer);
                if (idx > -1) mixers.splice(idx, 1);
            }
            delete pieceMeshes[sq];
            // Rigenera il pezzo corretto
            spawnPiece(boardPiece.type, boardPiece.color, sq);
        }
    }
}

// ==========================================================================
// 8. INTERAZIONE UTENTE E RAYCASTING (SELEZIONE & CLIC)
// ==========================================================================

/**
 * Gestisce il click del mouse/touch sulla scena
 */
function onPointerDown(event) {
    pointerStart.set(event.clientX, event.clientY);
}

function onPointerUp(event) {
    // Calcola lo spostamento per distinguere un click da una rotazione della telecamera (drag)
    const dist = Math.hypot(event.clientX - pointerStart.x, event.clientY - pointerStart.y);
    if (dist > 5) return; // Se lo spostamento è superiore a 5px, considera drag ed ignora

    // Impedisci click se c'è un'animazione in corso
    if (isAnimating) return;

    // Calcola coordinate mouse normalizzate nel range [-1, 1]
    const rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);

    // Raccogli tutti gli oggetti raycastabili (Tessere e Pezzi)
    const interactableObjects = [];
    for (let key in boardSquares3D) {
        interactableObjects.push(boardSquares3D[key]);
    }
    for (let key in pieceMeshes) {
        // Includi tutti i figli ricorsivi della mesh del pezzo
        pieceMeshes[key].mesh.traverse(child => {
            if (child.isMesh) {
                // Passa i dati del pezzo padre al figlio per il rilevamento
                child.userData.parentPiece = pieceMeshes[key];
                interactableObjects.push(child);
            }
        });
    }

    const intersects = raycaster.intersectObjects(interactableObjects, true);

    if (intersects.length > 0) {
        const hit = intersects[0].object;
        let clickedSquare = null;
        let clickedPiece = null;

        // Identifica cosa abbiamo cliccato
        if (hit.userData.isTile) {
            clickedSquare = hit.userData.square;
        } else if (hit.userData.parentPiece) {
            clickedPiece = hit.userData.parentPiece;
            clickedSquare = clickedPiece.mesh.userData.square;
        }

        if (clickedSquare) {
            handleSquareClick(clickedSquare, clickedPiece);
        }
    } else {
        // Click nel vuoto: deseleziona tutto
        clearSelection();
    }
}

/**
 * Gestisce il flusso logico del click su una casella
 */
function handleSquareClick(square, piece) {
    const activePlayer = chess.turn(); // 'w' o 'b'

    // Caso 1: Abbiamo già un pezzo selezionato e clicchiamo su una casella di mossa valida
    if (selectedSquare && validMoves.includes(square)) {
        // Recupera i dettagli del movimento logico per il log prima di eseguirlo
        const possibleMoves = chess.moves({ square: selectedSquare, verbose: true });
        const moveDetails = possibleMoves.find(m => m.to === square);
        
        clearHighlights();
        executeMove3D(selectedSquare, square, moveDetails);
        selectedSquare = null;
        validMoves = [];
    } 
    // Caso 2: Clicchiamo su un pezzo del giocatore attivo per selezionarlo
    else if (piece && piece.color === activePlayer) {
        clearSelection();
        
        selectedSquare = square;
        
        // Evidenzia casella selezionata (Oro)
        highlightSquare(square, COLOR_GOLD_HIGHLIGHT);
        
        // Ottieni mosse valide da chess.js
        const moves = chess.moves({ square: square, verbose: true });
        validMoves = moves.map(m => m.to);
        
        // Evidenzia mosse possibili (Blu per mossa normale, Rosso per cattura)
        validMoves.forEach(targetSquare => {
            const isCapture = chess.get(targetSquare) !== null;
            highlightSquare(targetSquare, isCapture ? COLOR_RED_HIGHLIGHT : COLOR_BLUE_HIGHLIGHT);
        });
    } 
    // Caso 3: Clicchiamo su una casella non valida
    else {
        clearSelection();
    }
}

/**
 * Evidenzia una singola casella colorandola
 */
function highlightSquare(square, colorHex) {
    const tile = boardSquares3D[square];
    if (tile) {
        tile.material.emissive.setHex(colorHex);
        tile.material.emissiveIntensity = 0.45;
    }
}

/**
 * Rimuove le evidenziazioni da tutte le tessere della scacchiera
 */
function clearHighlights() {
    for (let key in boardSquares3D) {
        boardSquares3D[key].material.emissive.setHex(0x000000);
        boardSquares3D[key].material.emissiveIntensity = 0.0;
    }
}

/**
 * Resetta lo stato di selezione attiva
 */
function clearSelection() {
    selectedSquare = null;
    validMoves = [];
    clearHighlights();
}

// ==========================================================================
// 9. GESTIONE TELECAMERA ED EVENTI VISTA (3D VS 2D)
// ==========================================================================

/**
 * Transizione fluida della telecamera tramite GSAP
 */
function toggleCameraView() {
    isTopDownView = !isTopDownView;
    const btn = document.getElementById('btn-view');
    
    // Configura parametri di arrivo in base alla vista
    let targetPos, targetLookAt;
    
    if (isTopDownView) {
        // Vista 2D Ortogonale dall'alto
        targetPos = { x: 0, y: 22, z: 0.01 }; // z: 0.01 previene il gimbal lock dei controlli di orbita
        targetLookAt = { x: 0, y: 0, z: 0 };
        btn.querySelector('.btn-text').innerText = "Vista 3D";
        btn.querySelector('.icon').innerText = "📐";
        
        // Disattiva rotazione dei controlli durante la vista bidimensionale
        controls.enableRotate = false;
    } else {
        // Vista 3D Isometrica
        targetPos = { x: 0, y: 15, z: 16 };
        targetLookAt = { x: 0, y: 0, z: 0 };
        btn.querySelector('.btn-text').innerText = "Vista 2D";
        btn.querySelector('.icon').innerText = "🎥";
        
        controls.enableRotate = true;
    }

    // Disabilita temporaneamente i controlli per non interferire con GSAP
    controls.enabled = false;

    gsap.timeline({
        onUpdate: () => {
            controls.update();
        },
        onComplete: () => {
            controls.enabled = true;
            if (isTopDownView) {
                // Fissa il bersaglio e la rotazione
                controls.target.set(0, 0, 0);
            }
        }
    })
    .to(camera.position, {
        x: targetPos.x,
        y: targetPos.y,
        z: targetPos.z,
        duration: 1.2,
        ease: "power2.inOut"
    }, 0)
    .to(controls.target, {
        x: targetLookAt.x,
        y: targetLookAt.y,
        z: targetLookAt.z,
        duration: 1.2,
        ease: "power2.inOut"
    }, 0);
}

/**
 * Imposta istantaneamente la posizione della camera
 */
function resetCameraPosition(isTopDown) {
    if (isTopDown) {
        camera.position.set(0, 22, 0.01);
    } else {
        camera.position.set(0, 15, 16);
    }
    if (controls) {
        controls.target.set(0, 0, 0);
        controls.update();
    }
}

// ==========================================================================
// 10. GESTIONE UI E STATO DI GIOCO
// ==========================================================================

/**
 * Configura tutti gli eventi DOM per i pulsanti della UI
 */
function setupUIEvents() {
    // Rilevamento click scacchiera 3D con filtro trascinamento
    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointerup', onPointerUp);

    // Bottone cambia vista
    document.getElementById('btn-view').addEventListener('click', toggleCameraView);

    // Bottoni di riavvio
    document.getElementById('btn-reset').addEventListener('click', restartGame);
    document.getElementById('btn-restart-game').addEventListener('click', () => {
        document.getElementById('game-over-overlay').classList.add('hidden');
        restartGame();
    });
}

/**
 * Aggiorna gli elementi HTML della UI dopo ogni mossa
 */
function updateUI(moveInfo) {
    const activePlayer = chess.turn() === 'w' ? 'BIANCO' : 'NERO';
    const turnIndicator = document.getElementById('turn-indicator');
    const currentPlayerLabel = document.getElementById('current-player');

    // Aggiorna indicatore del turno
    currentPlayerLabel.innerText = activePlayer;
    if (chess.turn() === 'w') {
        turnIndicator.className = "white-turn";
    } else {
        turnIndicator.className = "black-turn";
    }

    // Gestione pannello scacco logico
    const statusPanel = document.getElementById('status-panel');
    if (chess.in_check() && !chess.in_checkmate()) {
        statusPanel.classList.remove('hidden');
        document.getElementById('status-text').innerText = "SCACCO!";
    } else {
        statusPanel.classList.add('hidden');
    }

    // Aggiungi record nello Storico Mosse
    if (moveInfo) {
        addMoveToLog(moveInfo);
    }
}

/**
 * Aggiunge graficamente la mossa effettuata nel log della UI
 */
let moveCount = 1;
function addMoveToLog(move) {
    const list = document.getElementById('moves-list');
    
    // Traduzione simboli pezzi in italiano
    const pieceNames = { p: 'P', r: 'T', n: 'C', b: 'A', q: 'D', k: 'R' };
    const pieceSym = pieceNames[move.piece] || '';
    const notation = `${pieceSym}${move.from}-${move.to}`;

    if (move.color === 'w') {
        // Crea una nuova riga per il turno (mossa Bianco + futuro spazio Nero)
        const row = document.createElement('div');
        row.className = 'move-row';
        row.id = `move-row-${moveCount}`;
        
        row.innerHTML = `
            <span class="move-num">${moveCount}.</span>
            <span class="move-white">${notation}</span>
            <span class="move-black" id="black-move-${moveCount}">-</span>
        `;
        list.appendChild(row);
        list.scrollTop = list.scrollHeight;
    } else {
        // Inserisci la mossa del nero nella riga esistente
        const blackCell = document.getElementById(`black-move-${moveCount}`);
        if (blackCell) {
            blackCell.innerText = notation;
        }
        moveCount++;
    }
}

/**
 * Controlla se la partita è terminata ed attiva la UI finale
 */
function checkGameStatus() {
    const gameOverOverlay = document.getElementById('game-over-overlay');
    const title = document.getElementById('game-over-title');
    const msg = document.getElementById('game-over-msg');

    if (chess.in_checkmate()) {
        gameOverOverlay.classList.remove('hidden');
        title.innerText = "SCACCO MATTO!";
        const winner = chess.turn() === 'w' ? 'Nero' : 'Bianco';
        msg.innerText = `Il ${winner} ha vinto la partita per scacco matto.`;
    } else if (chess.in_draw()) {
        gameOverOverlay.classList.remove('hidden');
        title.innerText = "PATTA!";
        let reason = "La partita è terminata in parità.";
        if (chess.in_stalemate()) reason = "Stallo: il giocatore di turno non ha mosse legali e non è sotto scacco.";
        else if (chess.insufficient_material()) reason = "Materiale insufficiente per forzare lo scacco matto.";
        else if (chess.in_threefold_repetition()) reason = "Patta per triplice ripetizione della posizione.";
        msg.innerText = reason;
    }
}

/**
 * Ripristina il gioco allo stato iniziale
 */
function restartGame() {
    if (isAnimating) return;
    
    // Resetta chess.js
    chess.reset();
    
    // Svuota storico mosse
    document.getElementById('moves-list').innerHTML = '';
    moveCount = 1;

    // Ripristina UI di stato
    document.getElementById('status-panel').classList.add('hidden');
    updateUI();

    // Ricarica pezzi 3D
    document.getElementById('loading-overlay').classList.remove('hidden');
    document.getElementById('progress-bar').style.width = '0%';
    document.getElementById('loading-status').innerText = 'Ripristino scacchiera...';

    loadAllPieces().then(() => {
        document.getElementById('loading-overlay').classList.add('hidden');
    });
}

// ==========================================================================
// 11. FUNZIONI UTILITY (CONVERSIONE COORDINATE)
// ==========================================================================

/**
 * Converte indici matriciali (row, col) in notazione algebrica scacchi (es. 0,0 -> "a8")
 */
function coordsToAlgebraic(row, col) {
    const letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
    const rank = 8 - row;
    return letters[col] + rank;
}

/**
 * Converte la notazione algebrica (es. "e4") in coordinate cartesiane X, Z sulla scacchiera 3D
 */
function algebraicToCoords(square) {
    const col = square.charCodeAt(0) - 97; // 'a' -> 0, 'h' -> 7
    const row = 8 - parseInt(square.charAt(1)); // rank 8 -> row 0, rank 1 -> row 7
    
    // Calcoliamo i centri delle tessere basandoci sul TILE_SIZE
    const x = (col - BOARD_OFFSET) * TILE_SIZE;
    const z = (BOARD_OFFSET - row) * TILE_SIZE;
    
    return { x, z };
}

// ==========================================================================
// 12. LOOP DI ANIMAZIONE E RENDERIZZAZIONE
// ==========================================================================

/**
 * Gestisce il ridimensionamento della finestra per mantenere le proporzioni
 */
function onWindowResize() {
    const container = document.getElementById('canvas-container');
    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.clientWidth, container.clientHeight);
}

/**
 * Ciclo di renderizzazione principale (60 FPS / requestAnimationFrame)
 */
function animate() {
    requestAnimationFrame(animate);

    const deltaTime = clock.getDelta();

    // Aggiorna gli AnimationMixer attivi per i modelli GLB caricati
    for (let i = 0; i < mixers.length; i++) {
        mixers[i].update(deltaTime);
    }

    // Aggiorna OrbitControls (richiesto per damping)
    if (controls && controls.enabled) {
        controls.update();
    }

    // Disegna la scena
    renderer.render(scene, camera);
}
